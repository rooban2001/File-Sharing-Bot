from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

app = FastAPI(title="Movie Booking System API")


# 1. Pydantic Models

class Movie(BaseModel):
    id: int
    title: str
    duration_minutes: int = Field(gt=0, description="Movie duration must be positive")
    genre: str

class MovieCreate(BaseModel):
    title: str
    duration_minutes: int = Field(gt=0)
    genre: str

class Showtime(BaseModel):
    id: int
    movie_id: int
    start_time: datetime
    available_seats: int
    price: float = Field(gt=0)

class ShowtimeCreate(BaseModel):
    start_time: datetime
    price: float = Field(gt=0)

class Booking(BaseModel):
    id: int
    showtime_id: int
    customer_name: str
    seats_booked: int = Field(gt=0)
    total_amount: float

class BookingCreate(BaseModel):
    showtime_id: int
    customer_name: str
    seats_booked: int = Field(gt=0)



# 2. In-memory storage

movies: List[Movie] = []
showtimes: List[Showtime] = []
bookings: List[Booking] = []

movie_id_counter = 1
showtime_id_counter = 1
booking_id_counter = 1


# 3. Endpoints


#  Movies 
@app.get("/movies", response_model=List[Movie])
def get_movies():
    return movies

@app.post("/movies", response_model=Movie, status_code=201)
def add_movie(movie: MovieCreate):
    global movie_id_counter
    new_movie = Movie(
        id=movie_id_counter,
        title=movie.title,
        duration_minutes=movie.duration_minutes,
        genre=movie.genre
    )
    movies.append(new_movie)
    movie_id_counter += 1
    return new_movie


# Showtimes 
@app.get("/movies/{movie_id}/showtimes", response_model=List[Showtime])
def get_showtimes(movie_id: int):
    movie_exists = next((m for m in movies if m.id == movie_id), None)
    if not movie_exists:
        raise HTTPException(status_code=404, detail="Movie not found")
    return [s for s in showtimes if s.movie_id == movie_id]

@app.post("/movies/{movie_id}/showtimes", response_model=Showtime, status_code=201)
def add_showtime(movie_id: int, showtime: ShowtimeCreate):
    global showtime_id_counter
    movie_exists = next((m for m in movies if m.id == movie_id), None)
    if not movie_exists:
        raise HTTPException(status_code=404, detail="Movie not found")

    new_showtime = Showtime(
        id=showtime_id_counter,
        movie_id=movie_id,
        start_time=showtime.start_time,
        available_seats=50,  # default
        price=showtime.price
    )
    showtimes.append(new_showtime)
    showtime_id_counter += 1
    return new_showtime


#Bookings
@app.post("/bookings", response_model=Booking, status_code=201)
def create_booking(booking: BookingCreate):
    global booking_id_counter

    # Find showtime
    showtime = next((s for s in showtimes if s.id == booking.showtime_id), None)
    if not showtime:
        raise HTTPException(status_code=404, detail="Showtime not found")

    # Check seats availability
    if booking.seats_booked > showtime.available_seats:
        raise HTTPException(status_code=400, detail="Not enough available seats")

    # Calculate total
    total_amount = booking.seats_booked * showtime.price

    # Update seats
    showtime.available_seats -= booking.seats_booked

    # Create booking
    new_booking = Booking(
        id=booking_id_counter,
        showtime_id=booking.showtime_id,
        customer_name=booking.customer_name,
        seats_booked=booking.seats_booked,
        total_amount=total_amount
    )
    bookings.append(new_booking)
    booking_id_counter += 1
    return new_booking

@app.get("/bookings/{booking_id}", response_model=Booking)
def get_booking(booking_id: int):
    booking = next((b for b in bookings if b.id == booking_id), None)
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    return booking

@app.delete("/bookings/{booking_id}")
def cancel_booking(booking_id: int):
    booking = next((b for b in bookings if b.id == booking_id), None)
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")

    # Return seats
    showtime = next((s for s in showtimes if s.id == booking.showtime_id), None)
    if showtime:
        showtime.available_seats += booking.seats_booked

    bookings.remove(booking)
    return {"message": "Booking cancelled successfully"}
