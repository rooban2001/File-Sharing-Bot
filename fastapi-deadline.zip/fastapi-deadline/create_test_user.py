from sqlalchemy.orm import Session
from database import SessionLocal, Base, engine
from models import User, Role

# Create database tables
Base.metadata.create_all(bind=engine)

# Add a test user
def create_test_user():
    db: Session = SessionLocal()
    try:
        user = User(
            username="admin",
            password="adminpass",  # In production, hash this
            role=Role.admin
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        print(f"Created user: {user.username}")
    finally:
        db.close()

if __name__ == "__main__":
    create_test_user()