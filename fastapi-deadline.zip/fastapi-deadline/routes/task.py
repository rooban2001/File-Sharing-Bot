from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List
from database import SessionLocal
from models import Task, TaskState, TaskHistory, TaskTracking, User
from schemas import TaskCreate, TaskOut, TaskStatusUpdate, TaskHistoryOut
from auth import get_current_user, get_current_admin
from utils import require_role

router = APIRouter(prefix="/tasks", tags=["tasks"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=TaskOut)
def create_task(task: TaskCreate, current_user: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    
    print("task---------",current_user.id)
    db_task = Task(**task.model_dump())
    db.add(db_task)
    db.commit()
    db.refresh(db_task)
    # Record task creation in history
    history = TaskHistory(task_id=db_task.id, user_id=current_user.id, action="task_created")
    db.add(history)
    # Record initial task state in tracking
    
    tracking = TaskTracking(task_id=db_task.id, state=TaskState.pending)
    
    print("tracking----",tracking)
    db.add(tracking)
    db.commit()
    return db_task

@router.post("/{task_id}/assign/{user_id}")
def assign_user_to_task(task_id: int, user_id: int, current_user: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user not in task.assigned_users:
        task.assigned_users.append(user)
        history = TaskHistory(task_id=task_id, user_id=user_id, action="user_assigned")
        db.add(history)
        db.commit()
    return {"detail": "User assigned to task"}

@router.put("/{task_id}/status")
def update_task_status(task_id: int, status_update: TaskStatusUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    
    print("task_id------",task_id)
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    task.state = status_update.state
    # Record status update in history
    history = TaskHistory(task_id=task_id, user_id=current_user.id, action=f"status_updated_to_{status_update.state.value}")
    db.add(history)
    # Update tracking table
    tracking = TaskTracking(task_id=task_id, state=status_update.state)
    db.add(tracking)
    db.commit()
    return {"detail": "Task status updated"}

@router.get("/{task_id}", response_model=TaskOut)
def get_task(task_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.get("/{task_id}/history", response_model=List[TaskHistoryOut])
def get_task_history(task_id: int, current_user: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    history = db.query(TaskHistory).filter(TaskHistory.task_id == task_id).all()
    return history

@router.get("/summaries/")
def get_task_summaries(current_user: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    now = datetime.utcnow()
    total_tasks = db.query(Task).count()
    completed = db.query(TaskTracking).filter(TaskTracking.state == TaskState.completed).count()
    pending = db.query(TaskTracking).filter(TaskTracking.state == TaskState.pending).count()
    in_progress = db.query(TaskTracking).filter(TaskTracking.state == TaskState.in_progress).count()
    overdue = db.query(Task).filter(Task.state != TaskState.completed, Task.deadline < now).count()
    return {
        "total_tasks": total_tasks,
        "completed": completed,
        "pending": pending,
        "in_progress": in_progress,
        "overdue": overdue
    }

 