from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal
from schemas import UserCreate, UserOut
from models import User
from auth import get_current_admin
from utils import check_username_exists
import logging

router = APIRouter(prefix="/users", tags=["users"])
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/users", response_model=UserOut)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    if check_username_exists(db, user.username):
        raise HTTPException(status_code=400, detail="Username already registered")
    db_user = User(username=user.username, password=user.password, role=user.role)  # Hash password in production
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user