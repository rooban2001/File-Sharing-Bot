from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from jose import jwt, JWTError
from datetime import datetime, timedelta, timezone
from database import SessionLocal
from models import User, Role

# JWT setup
SECRET_KEY = "a1b2c3d4e5f6g7h8i9j0"  # Use a strong, consistent key
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

oauth2_scheme = HTTPBearer()

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire, "role": data.get("role")})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    # Extract token string from HTTPAuthorizationCredentials
    try:
        token = credentials.credentials
    except Exception:
        raise credentials_exception
    print(f"Token: {token}")  # Debug
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        print(f"Payload: {payload}")  # Debug
        username: str = payload.get("sub")
        if username is None:
            print("No username in token payload")  # Debug
            raise credentials_exception
    except JWTError as e:
        print(f"JWT Error: {e}")  # Debug
        raise credentials_exception
    db = SessionLocal()
    user = db.query(User).filter(User.username == username).first()
    print(f"User found: {user}")  # Debug
    db.close()
    if user is None:
        print(f"No user found for username: {username}")  # Debug
        raise credentials_exception
    return user

async def get_current_admin(current_user: User = Depends(get_current_user)):
    if current_user.role != Role.admin:
        raise HTTPException(status_code=403, detail="Admin privileges required")
    return current_user