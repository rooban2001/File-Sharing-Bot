from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from database import Base, engine
from auth import create_access_token
from models import User
from routes.user import router as user_router
from routes.task import router as task_router

# Create database tables
Base.metadata.create_all(bind=engine)

# FastAPI app
app = FastAPI()

# Include routers
app.include_router(user_router)
app.include_router(task_router)

# Authentication endpoint
@app.post("/token")
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    from database import SessionLocal
    db = SessionLocal()
    user = db.query(User).filter(User.username == form_data.username).first()
    db.close()
    if not user or user.password != form_data.password:  # In production, use hashed password comparison
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    access_token = create_access_token(data={"sub": user.username, "role": user.role.value})
    return {"access_token": access_token, "token_type": "bearer"}