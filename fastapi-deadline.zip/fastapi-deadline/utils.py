from asyncio import tasks
from fastapi import HTTPException,Depends
from sqlalchemy.orm import Session
from models import User
from functools import wraps
from typing import Callable
from auth import get_current_user



def check_username_exists(db: Session, username: str) -> bool:
    """Helper function to check if username exists in the database."""
    return db.query(User).filter(User.username == username).first() is not None

def require_role(role: str) -> Callable:
    """Decorator to restrict access based on user role."""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, current_user: User = Depends(get_current_user), **kwargs):
            if current_user.role.value != role:
                raise HTTPException(status_code=403, detail=f"{role.capitalize()} role required")
            return func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator