from pydantic import BaseModel
from datetime import datetime
from typing import List
from models import Role, TaskState

class UserBase(BaseModel):
    username: str
    password:str
    role: Role

class UserCreate(UserBase):
    password: str

class UserOut(UserBase):
    id: int

    class Config:
        from_attributes = True

class TaskBase(BaseModel):
    title: str
    description: str
    deadline: datetime

class TaskCreate(TaskBase):
    pass

class TaskOut(TaskBase):
    id: int
    state: TaskState
    assigned_users: List[UserOut]

    class Config:
        from_attributes = True

class TaskStatusUpdate(BaseModel):
    state: TaskState

class TaskHistoryOut(BaseModel):
    id: int
    task_id: int
    user_id: int
    action: str
    timestamp: datetime

    class Config:
        from_attributes = True