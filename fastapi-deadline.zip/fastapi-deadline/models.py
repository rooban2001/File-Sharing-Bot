from sqlalchemy import Column, Integer, String, DateTime, Enum, ForeignKey
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime
import enum

# Enums
class Role(enum.Enum):
    user = "user"
    admin = "admin"

class TaskState(enum.Enum):
    pending = "pending"
    in_progress = "in_progress"
    completed = "completed"

# Models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    password = Column(String)  # In production, hash this
    role = Column(Enum(Role))
    assigned_tasks = relationship("Task", secondary="task_assignments", back_populates="assigned_users")
    task_history = relationship("TaskHistory", back_populates="user")

class Task(Base):
    __tablename__ = "tasks"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)
    description = Column(String)
    deadline = Column(DateTime)
    state = Column(Enum(TaskState), default=TaskState.pending)
    assigned_users = relationship("User", secondary="task_assignments", back_populates="assigned_tasks")
    history = relationship("TaskHistory", back_populates="task")
    

class TaskAssignment(Base):
    __tablename__ = "task_assignments"
    task_id = Column(Integer, ForeignKey("tasks.id"), primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)

class TaskHistory(Base):
    __tablename__ = "task_history"
    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String)  # e.g., "status_updated", "assigned"
    timestamp = Column(DateTime, default=datetime.utcnow)
    task = relationship("Task", back_populates="history")
    user = relationship("User", back_populates="task_history")

class TaskTracking(Base):
    __tablename__ = "task_tracking"
    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"))
    state = Column(Enum(TaskState))
    recorded_at = Column(DateTime, default=datetime.utcnow)