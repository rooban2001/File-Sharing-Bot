# utilis.py
from datetime import datetime, timezone
from passlib.context import CryptContext
from sqlmodel import select, Session
from typing import Optional

# Corrected imports
from models import User, Task
from schemas import TaskRead

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# --- Password Helpers ---

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_user_by_username(session: Session, username: str) -> Optional[User]:
    statement = select(User).where(User.username == username)
    return session.exec(statement).first()

# --- Task Conversion Utility ---

def task_to_read(task: Task) -> TaskRead:
    assigned_ids = [u.id for u in task.assigned_users]
    now = datetime.now(timezone.utc)
    deadline_aware = task.deadline.replace(tzinfo=timezone.utc) if task.deadline.tzinfo is None else task.deadline
    
    overdue = (deadline_aware < now) and (task.status != "completed")
    
    return TaskRead(
        id=task.id,
        title=task.title,
        description=task.description,
        deadline=task.deadline,
        status=task.status,
        assigned_user_ids=assigned_ids,
        overdue=overdue,
        created_at=task.created_at,
    )