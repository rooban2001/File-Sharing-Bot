# schemas.py
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel

class Token(BaseModel):
    access_token: str
    token_type: str

class UserCreate(BaseModel):
    username: str
    password: str
    role: Optional[str] = "user"

class UserRead(BaseModel):
    id: int
    username: str
    role: str

class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = ""
    deadline: datetime
    assigned_user_ids: Optional[List[int]] = []

class TaskRead(BaseModel):
    id: int
    title: str
    description: Optional[str]
    deadline: datetime
    status: str
    assigned_user_ids: List[int]
    overdue: bool
    created_at: datetime

class TaskUpdate(BaseModel):
    status: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    deadline: Optional[datetime] = None
    assigned_user_ids: Optional[List[int]] = None