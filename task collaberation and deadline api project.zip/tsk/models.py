# models.py
from datetime import datetime
from typing import List, Optional
from sqlmodel import SQLModel, Field, Relationship

class UserTaskLink(SQLModel, table=True):
    user_id: Optional[int] = Field(default=None, foreign_key="user.id", primary_key=True)
    task_id: Optional[int] = Field(default=None, foreign_key="task.id", primary_key=True)

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True)
    hashed_password: str
    role: str = Field(default="user")  # 'admin' or 'user'
    tasks: List["Task"] = Relationship(back_populates="assigned_users", link_model=UserTaskLink)

class Task(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: Optional[str] = ""
    deadline: datetime
    status: str = Field(default="pending")  # pending / in-progress / completed
    created_at: datetime = Field(default_factory=datetime.utcnow)
    assigned_users: List[User] = Relationship(back_populates="tasks", link_model=UserTaskLink)