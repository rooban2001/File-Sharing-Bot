# routes/__init__.py
# (Empty file to mark directory as a Python package)