# routes/tasks.py
from datetime import datetime, timezone
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select

# Corrected imports
from database import get_session
from models import Task, User, UserTaskLink
from schemas import TaskCreate, TaskRead, TaskUpdate
from auth import get_current_user, require_role
from utility import task_to_read

router = APIRouter(tags=["Tasks"])

# Create task (admin only)
@router.post("/tasks", response_model=TaskRead, dependencies=[Depends(require_role("admin"))])
def create_task(task_in: TaskCreate, session: Session = Depends(get_session)):
    assigned_users = []
    for uid in (task_in.assigned_user_ids or []):
        u = session.get(User, uid)
        if not u:
            raise HTTPException(status_code=404, detail=f"Assigned user id {uid} not found")
        assigned_users.append(u)
        
    task = Task(
        title=task_in.title,
        description=task_in.description,
        deadline=task_in.deadline,
        status="pending",
        assigned_users=assigned_users,
    )
    session.add(task)
    session.commit()
    session.refresh(task)
    return task_to_read(task)


# List tasks (admin -> all tasks, user -> only assigned)
@router.get("/tasks", response_model=List[TaskRead])
def list_tasks(current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    if current_user.role == "admin":
        statement = select(Task)
        tasks = session.exec(statement).all()
    else:
        # Select tasks joined via link table
        statement = (
            select(Task)
            .join(UserTaskLink, UserTaskLink.task_id == Task.id)
            .where(UserTaskLink.user_id == current_user.id)
        )
        tasks = session.exec(statement).all()
        
    return [task_to_read(t) for t in tasks]


# Get a specific task (permission enforced)
@router.get("/tasks/{task_id}", response_model=TaskRead)
def get_task(task_id: int, current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    task = session.get(Task, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    if current_user.role != "admin" and current_user.id not in [u.id for u in task.assigned_users]:
        raise HTTPException(status_code=403, detail="Not allowed to view this task")
        
    return task_to_read(task)


# Update task - admin can update all fields; users can only update status on their tasks
@router.patch("/tasks/{task_id}", response_model=TaskRead)
def update_task(task_id: int, updates: TaskUpdate, current_user: User = Depends(get_current_user), session: Session = Depends(get_session)):
    task = session.get(Task, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
        
    if current_user.role != "admin":
        if current_user.id not in [u.id for u in task.assigned_users]:
            raise HTTPException(status_code=403, detail="Not allowed to modify this task")
        # Users may only change status
        if updates.status is None and any(v is not None for k, v in updates.dict().items() if k != 'status'):
            raise HTTPException(status_code=403, detail="Users can only update the status")
        
    # Apply updates
    update_data = updates.dict(exclude_unset=True)
    
    if "status" in update_data:
        if updates.status not in ("pending", "in-progress", "completed"):
            raise HTTPException(status_code=400, detail="Invalid status")
        task.status = updates.status

    if current_user.role == "admin":
        if "title" in update_data:
            task.title = updates.title
        if "description" in update_data:
            task.description = updates.description
        if "deadline" in update_data:
            task.deadline = updates.deadline
            
        if "assigned_user_ids" in update_data:
            new_assigned = []
            for uid in updates.assigned_user_ids:
                u = session.get(User, uid)
                if not u:
                    raise HTTPException(status_code=404, detail=f"User id {uid} not found")
                new_assigned.append(u)
            task.assigned_users = new_assigned
            
    session.add(task)
    session.commit()
    session.refresh(task)
    return task_to_read(task)

# Admin summary
@router.get("/admin/summary", dependencies=[Depends(require_role("admin"))])
def admin_summary(session: Session = Depends(get_session)):
    statement = select(Task)
    tasks = session.exec(statement).all()
    now = datetime.now(timezone.utc)
    
    total = len(tasks)
    completed = sum(1 for t in tasks if t.status == "completed")
    pending = sum(1 for t in tasks if t.status in ("pending", "in-progress"))
    overdue = sum(1 for t in tasks if (t.deadline.replace(tzinfo=timezone.utc) < now and t.status != "completed"))
    
    per_user = {}
    users = session.exec(select(User)).all()
    
    for u in users:
        u_tasks = [t for t in tasks if u in t.assigned_users]
        per_user[u.username] = {
            "total": len(u_tasks),
            "completed": sum(1 for t in u_tasks if t.status == "completed"),
            "overdue": sum(1 for t in u_tasks if (t.deadline.replace(tzinfo=timezone.utc) < now and t.status != "completed"))
        }
        
    return {
        "total_tasks": total,
        "completed": completed,
        "pending_or_in_progress": pending,
        "overdue": overdue,
        "per_user": per_user,
    }


# Admin list overdue tasks
@router.get("/admin/overdue", response_model=List[TaskRead], dependencies=[Depends(require_role("admin"))])
def list_overdue(session: Session = Depends(get_session)):
    statement = select(Task)
    tasks = session.exec(statement).all()
    now = datetime.now(timezone.utc)
    
    overdue_tasks = [task_to_read(t) for t in tasks if (t.deadline.replace(tzinfo=timezone.utc) < now and t.status != "completed")]
    return overdue_tasks