# routes/users.py
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlmodel import Session

# Corrected imports
from database import get_session
from models import User
from schemas import UserCreate, UserRead, Token
from auth import authenticate_user, create_access_token, get_current_user
from utility import get_password_hash, get_user_by_username

router = APIRouter(tags=["Users & Auth"])

# Auth Configuration (needed for token creation time)
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 

@router.post("/register", response_model=UserRead)
def register(user_create: UserCreate, session: Session = Depends(get_session)):
    if get_user_by_username(session, user_create.username):
        raise HTTPException(status_code=400, detail="Username already registered")
    
    role_value = user_create.role if user_create.role in ("admin", "user") else "user"
    user = User(
        username=user_create.username,
        hashed_password=get_password_hash(user_create.password),
        role=role_value,
    )
    session.add(user)
    session.commit()
    session.refresh(user)
    return UserRead(id=user.id, username=user.username, role=user.role)

@router.post("/token", response_model=Token)
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), session: Session = Depends(get_session)):
    user = authenticate_user(session, form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(data={"sub": user.username, "role": user.role}, expires_delta=access_token_expires)
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=UserRead)
def read_me(current_user: User = Depends(get_current_user)):
    return UserRead(id=current_user.id, username=current_user.username, role=current_user.role)