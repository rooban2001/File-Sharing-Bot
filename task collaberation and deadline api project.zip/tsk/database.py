# database.py
from sqlmodel import create_engine, SQLModel, Session
# Corrected import
from models import User, Task, UserTaskLink 

# DB setup
sqlite_file_name = "database.db"
sqlite_url = f"sqlite:///{sqlite_file_name}"
engine = create_engine(sqlite_url, echo=False, connect_args={"check_same_thread": False})

def create_db_and_tables():
    """Initializes the database and creates all defined tables."""
    SQLModel.metadata.create_all(engine)

def get_session():
    """FastAPI Dependency to get a database session."""
    with Session(engine) as session:
        yield session

create_db_and_tables()