# main.py
from fastapi import FastAPI
# Using direct module names for top-level loading
import routes.user as user
import routes.task as task 

app = FastAPI(title="Task Collaboration & Deadlines API")

# Include routers
app.include_router(user.router)
app.include_router(task.router)