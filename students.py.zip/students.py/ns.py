import statistics

# 1: Read and organize data ----------
students = {}

with open("student.txt", "r") as f:
    for line in f:
        parts = line.strip().split(",")
        name = parts[0]
        subjects = {}
        for i in range(1, len(parts), 2):
            subject = parts[i]
            score_str = parts[i+1].strip()

            if score_str == "":   
                score = 0
            else:
                score = int(score_str)

            subjects[subject] = score
        students[name] = subjects

# 2: Calculate student-level stats 
student_summary = {}

for name, subjects in students.items():
    scores = list(subjects.values())
    avg = sum(scores) / len(scores)

    # Letter grade
    if avg >= 90:
        grade = "A"
    elif avg >= 80:
        grade = "B"
    elif avg >= 70:
        grade = "C"
    elif avg >= 60:
        grade = "D"
    else:
        grade = "F"

    # Best and worst subject
    best_subject = max(subjects, key=subjects.get)
    worst_subject = min(subjects, key=subjects.get)

    student_summary[name] = {
        "average": avg,
        "grade": grade,
        "best": best_subject,
        "worst": worst_subject
    }

# 3: Class-level analysis 
subject_scores = {}
for subjects in students.values():
    for subject, score in subjects.items():
        subject_scores.setdefault(subject, []).append(score)

# Class averages
subject_averages = {sub: sum(scores)/len(scores) for sub, scores in subject_scores.items()}

# Best subject overall
best_subject_overall = max(subject_averages, key=subject_averages.get)

# Students above class average in each subject
above_class_avg = {}
for subject, scores in subject_scores.items():
    avg = subject_averages[subject]
    count = sum(1 for student, subs in students.items() if subs[subject] > avg)
    above_class_avg[subject] = count

# Students needing help (avg < 75)
students_need_help = [name for name, info in student_summary.items() if info["average"] < 75]

# 4: Generate report 
with open("report.txt", "w") as f:
    f.write("Student Performance Report\n\n")
    for name, info in student_summary.items():
        f.write(f"{name} -> Avg: {info['average']:.2f}, Grade: {info['grade']}, "
                f"Best: {info['best']}, Worst: {info['worst']}\n")

    f.write("\nClass Analysis\n")
    f.write(f"Highest Class Average Subject: {best_subject_overall} ({subject_averages[best_subject_overall]:.2f})\n")

    f.write("\nStudents above class average in each subject:\n")
    for subject, count in above_class_avg.items():
        f.write(f"{subject}: {count}\n")

    f.write("\nStudents who need help (avg < 75):\n")
    for student in students_need_help:
        f.write(student + "\n")
